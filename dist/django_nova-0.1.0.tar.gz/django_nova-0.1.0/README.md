Django Nova: Типизированный, унифицированный, асинхронно-ориентированный инструментарий Django
Django Nova устраняет фундаментальные архитектурные недостатки Django, которые приводят к повреждению данных, ошибкам во время выполнения и проблемам с поддержкой в ​​научном и корпоративном программном обеспечении.

Основные инновации
Единый источник достоверной информации для валидации : определите валидацию в Pydantic. Модели Django, формы и API будут считывать данные из него. Больше никакого дублирования.
Строгая типобезопасность : полная pyright --strictсовместимость с ORM, QuerySets и Models.
Интеллектуальное кэширование : автоматическая аннулирование данных при записи. Отсутствие устаревших данных в исследовательских конвейерах.
Миграция без простоев : операции, изначально разработанные для PostgreSQL CONCURRENTLY, для заблокированных таблиц.
Встроенный механизм задач : asyncioсредство запуска задач на основе Celery/RabbitMQ. Для пакетных заданий не требуется Celery/RabbitMQ.

Архитектура

Request -> View -> Model.save() -> [Pydantic Validation -> Django Fields -> Business Logic] -> DB
                |
                +-> Cache Invalidation Signal -> Evict stale QuerySets


Лицензия
MIT

Запуск:  pytest tests/test_full_integration.py -v


---

## 16. Инициализация пакета `src/nova/__init__.py`

```python
"""
Django Nova: Next-generation Django toolkit.
"""
__version__ = "0.1.0"

# Import key components for easy access: from nova import NovaModel, NovaConfig
from nova.typing.models import NovaModel, NovaConfig
from nova.cache.invalidation import connect_invalidation

__all__ = ["NovaModel", "NovaConfig", "connect_invalidation", "__version__"]